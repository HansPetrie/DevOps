#!/bin/bash
chmod -R 644 /var/www/html/WordPress
